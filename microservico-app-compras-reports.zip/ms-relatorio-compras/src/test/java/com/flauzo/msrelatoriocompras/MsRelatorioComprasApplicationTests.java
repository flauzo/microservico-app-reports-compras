package com.flauzo.msrelatoriocompras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsRelatorioComprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
