package com.flauzo.msrelatoriocompras.service.exception;

public class ExternalAPIConnectionException extends RuntimeException {

    public ExternalAPIConnectionException(String msg) {
        super(msg);
    }
}
