package com.flauzo.mseurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
